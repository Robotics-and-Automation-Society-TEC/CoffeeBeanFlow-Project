﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CoffeBeanFlowDB.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate_Area_AcopioContext : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
