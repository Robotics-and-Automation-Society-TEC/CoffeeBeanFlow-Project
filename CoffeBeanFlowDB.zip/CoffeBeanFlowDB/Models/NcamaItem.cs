namespace CoffeBeanFlowDB.Models;

public class NcamaItem
{
    // Llave primaria
    public int ID_Ncama { get; set; }
 
    // Llave foránea
    public int ID_Secado { get; set; }
}