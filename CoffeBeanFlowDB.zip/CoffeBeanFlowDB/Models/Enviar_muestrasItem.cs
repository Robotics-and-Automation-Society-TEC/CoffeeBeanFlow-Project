namespace CoffeBeanFlowDB.Models;

public class Enviar_muestrasItem
{
    // Llave primaria
    public int ID_Trilla { get; set; }
    
    // Llave foránea
    public int ID_Catacion { get; set; }
    
}