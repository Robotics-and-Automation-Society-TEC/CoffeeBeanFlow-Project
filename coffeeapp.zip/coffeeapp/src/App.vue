<!-- src/App.vue -->
<template>
    <router-view />
</template>

<script>
export default {
  name: "App",
};
</script>

<style>
/* estilos globales si quieres */
</style>
